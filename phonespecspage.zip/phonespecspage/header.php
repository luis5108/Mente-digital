<header class="header">
    <nav class="navbar">
        <div class="logo">mente<span class="neon-text">-digital</span></div>
        <ul class="nav-links">
            <li><a href="catalogo.php">Catálogo</a></li>
            <li><a href="comparador.php">Comparador</a></li>
            <li><a href="nosotros.php">Nosotros</a></li>
            <li><a href="faq.php">FAQ</a></li>
            <li><a href="contacto.php">Contacto</a></li>
            <li><a href="login.php">acceder</a></li>
        </ul>
    </nav>
</header>
